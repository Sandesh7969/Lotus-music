export default class Badges extends Object {
    owner;
    developer;
    staff;
    codev;
    supporter;
    admin;
    vip;
    friend;
    angel;
    user;
    bug;
    mod;
    communityManager;
    constructor() {
        super();
        this.owner = "1191411499491676231";
        this.developer = "1191411562540433540";
        this.communityManager = "";
        this.staff = "1191411600201105539";
        this.admin = "1191411628495876106";
        this.codev = "1191411659663749224";
        this.supporter = "1191411702286258306";
        this.vip = "1191411752680824926";
        this.friend = "";
        this.angel = "1183435569305497741";
        this.user = "1183400792061906964";
        this.bug = "1169186610085122128";
        this.mod = "1191411793973760030";
    }
}
//# sourceMappingURL=Badges.js.map