export default class OrasCommand {
    client;
    name;
    exec;
    aliases;
    cat;
    vote;
    vc;
    samevc;
    dev;
    manage;
    desc;
    usage;
    premium;
    playing;
    moment;
    dispatcher;
    constructor(client) {
        this.client = client;
    }
}
//# sourceMappingURL=OrasCommand.js.map